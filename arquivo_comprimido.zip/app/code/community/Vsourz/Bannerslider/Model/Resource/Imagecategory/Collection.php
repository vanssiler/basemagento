<?php
class Vsourz_Bannerslider_Model_Resource_Imagecategory_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract{
	public function _construct(){
		$this->_init('bannerslider/imagecategory');
	}
}