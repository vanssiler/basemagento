<?php
class Vsourz_Bannerslider_Model_Resource_Imagedetail_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract{
	public function _construct(){
		$this->_init('bannerslider/imagedetail');
	}
}