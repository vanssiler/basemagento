<?php
class Vsourz_Bannerslider_Helper_Data extends Mage_Core_Helper_Abstract{ 
}